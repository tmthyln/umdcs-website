package section0109;

public class RectangleArea {

    public static void main(String[] args) {
	double height = 0.5, width = 12.1;
	
	double area = height * width;
	
	System.out.println("Area of rectangle with width " + width 
		+ " and height " + height + " has area " + area + ".");

    }

}
