package section0109;

public class SlashPrint {

    public static void main(String[] args) {
	System.out.println("\tC:\n\\tmp\\prog");

    }

}
