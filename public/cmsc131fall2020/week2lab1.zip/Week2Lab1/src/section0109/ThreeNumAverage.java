package section0109;

import java.util.Scanner;

public class ThreeNumAverage {

    public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	
	System.out.print("Enter 3 numbers: ");
	
	double a, b, c;
	a = scanner.nextDouble();
	b = scanner.nextDouble();
	c = scanner.nextDouble();
	
	double avg = (a + b + c) / 3.0;
	System.out.println("Average is " + avg + ".");
	
	scanner.close();
    }

}
