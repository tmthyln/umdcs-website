package section0108;

public class SlashPrint {

    public static void main(String[] args) {
	System.out.println("C:\\tmp\\prog");

    }

}
