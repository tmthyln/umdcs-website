package section0108;

public class QuotePrint {

    public static void main(String[] args) {
	System.out.println("Robert \"bob\" Smith");

    }

}
