package section0108;

import java.util.Scanner;

public class TriadAverage {

    public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	double a, b, c;
	
	System.out.println("Enter 3 numbers: ");
	
	a = scanner.nextDouble();
	b = scanner.nextDouble();
	c = scanner.nextDouble();
	
	double average = (a + b + c) / 3;
	
	System.out.println("Average is " + average);
	
	scanner.close();
    }

}
