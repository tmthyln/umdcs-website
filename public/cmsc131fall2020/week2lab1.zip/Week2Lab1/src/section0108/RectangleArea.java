package section0108;

public class RectangleArea {

    public static void main(String[] args) {
	double height = 1.2, width = 0.5;
	double area = height * width;
	System.out.println("Area of a rectangle with height " + height 
		+ " and width " + width + " is " + area + ".");
    }

}
