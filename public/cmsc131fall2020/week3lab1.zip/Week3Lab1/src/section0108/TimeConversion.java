package section0108;

import java.util.Scanner;

public class TimeConversion {

    public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
	
	while (true) {
        	String ampmTime = input.nextLine();  // goal: convert to "0730"
        	
        	ampmTime = ampmTime.replace(":", " ");
        
        	Scanner scanner = new Scanner(ampmTime);
        	
        	int hour = scanner.nextInt();
        	int minutes = scanner.nextInt();
        	boolean isAM = scanner.next().equals("AM");
        	
        	String militaryHours;
        	if (isAM) {
        	    if (hour < 10) {
        		militaryHours = "0" + hour;
        	    } else {
        		militaryHours = "" + hour;
        	    }
        	} else {
        	    militaryHours = "" + (hour + 12);
        	}
        	
        	String militaryMinutes;
        	if (minutes < 10) {
        	    militaryMinutes = "0" + minutes;
        	} else {
        	    militaryMinutes = "" + minutes;
        	}
        	
        	System.out.println(militaryHours + militaryMinutes);
	}
    }

}
