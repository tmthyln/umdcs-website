package section0109;

import java.util.Scanner;

public class TimeConversion {

    public static void main(String[] args) {
	Scanner input = new Scanner(System.in);

	while (true) {
        	String line = input.nextLine();
        	
        	line = line.replace(":", " ");
        	
        	Scanner lineScanner = new Scanner(line);
        	int hour = lineScanner.nextInt();
        	int minute = lineScanner.nextInt();
        	String amPmString = lineScanner.next();
        	
        	String militaryHour;
        	if (amPmString.equalsIgnoreCase("AM")) {
        	    if (hour < 10) {
        		militaryHour = "0" + hour;
        	    } else if(hour == 12) { 
        		militaryHour = "00";
        	    } else {
        		militaryHour = "" + hour;
        	    }
        	} else {
        	    if (hour == 12) {
        		militaryHour = "12";
        	    } else {
        		militaryHour = "" + (hour + 12);
        	    }
        	}
        	
        	String militaryMinute;
        	if (minute < 10) {
        	    militaryMinute = "0" + minute;
        	} else {
        	    militaryMinute = "" + minute;
        	}
        	
        	System.out.println(militaryHour + militaryMinute);
	}
    }

}
