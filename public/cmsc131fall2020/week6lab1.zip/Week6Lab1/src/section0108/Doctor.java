package section0108;

public class Doctor {
    private String name;
    private String specialty;
    private int yearsOfExperience;
    private StringBuffer patientsSeen;
    
    private static int numDoctors = 0;
    
    public Doctor(String name, String specialty, int yearsOfExperience) {
	this.name = name;
	this.specialty = specialty;
	checkYears(yearsOfExperience);
	
	patientsSeen = new StringBuffer();
	
	numDoctors++;
    }
    
    public Doctor(String name, String specialty) {
	this(name, specialty, 0);
    }
    
    public Doctor() {
	this("NONAME", "GENERAL");
    }
    
    public void increaseExperience(int additionalYears) {
	checkYears(yearsOfExperience + additionalYears);
    }
    
    public String getSpecialty() {
        return this.specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }
    
    public void seePatient(String patient) {
	if (patient != null) {
	    patientsSeen.append(patient);
	}
    }

    public String toString() {
	return name + "," + specialty + "," + yearsOfExperience + "," + patientsSeen;
    }
    
    private void checkYears(int years) {
	if (years >= 0 && years <= 75) {
	    yearsOfExperience = years;
	}
    }
}
