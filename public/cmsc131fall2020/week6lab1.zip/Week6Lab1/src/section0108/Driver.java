package section0108;

public class Driver {

    public static void main(String[] args) {
	Doctor doc1 = new Doctor("Frank", "Dermatology", 5);
	Doctor doc2 = new Doctor("Sham", "Epithemiology");
	Doctor doc3 = new Doctor();
	
	doc1.seePatient("Alexis");
	doc1.seePatient("Nelson");
	
	doc3.increaseExperience(3);
	
	doc3.setSpecialty("Cardiac surgery");
	
	System.out.println(doc1);
	System.out.println(doc2);
	System.out.println(doc3);

    }

}
