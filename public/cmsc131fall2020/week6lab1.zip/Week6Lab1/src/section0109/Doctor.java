package section0109;

public class Doctor {
    private String name;
    private String specialty;
    private int yearsOfExperience;
    private StringBuffer patientsSeen;
    
    private static int numDoctors = 0;
    
    public Doctor(String name, String specialty, int yearsOfExperience) {
	this.name = name;
	this.specialty = specialty;
	yearsValid(yearsOfExperience);
	
	patientsSeen = new StringBuffer();
	
	numDoctors++;
    }
    
    public Doctor(String name, String specialty) {
	this(name, specialty, 0);
    }
    
    public Doctor() {
	this("NONAME", "GENERAL");
    }
    
    public void increaseExperience(int additionalYears) {
	yearsValid(yearsOfExperience + additionalYears);
    }
    
    public String getSpecialty() {
        return this.specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }
    
    public void seePatient(String name) {
	if (name != null) {
	    patientsSeen.append(name);
	}
    }

    public String toString() {
	return name + "," + specialty + "," + yearsOfExperience + "," + patientsSeen;
    }
    
    private void yearsValid(int years) {
	if (years >= 0 && years <= 75) {
	    yearsOfExperience = years;
	}
    }

    public static int getNumDoctors() {
        return numDoctors;
    }
    
    public static void resetNumDoctors() {
	numDoctors = 0;
    }
    
}
