package section0109;

import org.junit.Test;

public class StudentTests {

    @Test
    public void testConstructors() {
	Doctor doc1 = new Doctor("Nelson", "Computer Science", 28);
	Doctor doc2 = new Doctor("Phony", "Fake");
	
	
	System.out.println(doc1);
	System.out.println(doc2);
	
    }
    
    @Test
    public void testDefaultConstructor() {
	Doctor doc3 = new Doctor();
	
	System.out.println(doc3);
    }

}
