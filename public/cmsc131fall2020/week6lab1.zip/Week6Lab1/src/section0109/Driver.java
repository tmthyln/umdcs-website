package section0109;

public class Driver {

    public static void main(String[] args) {
	Doctor doc1 = new Doctor("Nelson", "Computer Science", 28);
	Doctor doc2 = new Doctor("Phony", "Fake");
	Doctor doc3 = new Doctor();
	
	doc1.seePatient("Fawzi");
	doc1.seePatient("Roger");
	doc1.seePatient("Alexis");
	doc2.increaseExperience(5);
	doc3.setSpecialty("Dermatology");
	
	System.out.println(doc1);
	System.out.println(doc2);
	System.out.println(doc3);

    }

}
