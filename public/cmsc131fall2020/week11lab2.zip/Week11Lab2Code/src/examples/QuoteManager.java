package examples;
import java.util.Random;

public class QuoteManager {
	private Quote[] allQuotes;
	private int numberOfQuotes;

	public QuoteManager(int maxQuotes) {
		allQuotes = new Quote[maxQuotes];
		numberOfQuotes = 0;
		/* Why we don't have a maxQuotes instance variable? */
	}

	public boolean addQuote(String quote, String type) {
		if (numberOfQuotes == allQuotes.length) {
			System.err.println("Full, no more quotes allowed");
			return false;
		}

		/* Notice all the things we are doing in a single statement */
		allQuotes[numberOfQuotes++] = new Quote(quote, type);

		return true;
	}

	public void printQuotes(String type) {
		/* Notice how we are using the ?: operator */
		System.out.println("\nQuotes of type: " + (type == null ? "all types" : type));
		for (int i = 0; i < numberOfQuotes; i++) {
			Quote quote = allQuotes[i]; /* Simplifies code */
			if (type == null || (type != null && type == quote.getType())) {
				System.out.println(quote);
			}
		}
	}

	/* Getting random quote */
	public Quote getRandomQuote(Random random) {
		return allQuotes[random.nextInt(numberOfQuotes)];
	}

	/* Finding how many quotes of a particular type */
	public Quote[] getQuotes(String type) {
		int count = 0;

		/*
		 * Why we cannot use this loop? for (Quote quote : allQuotes) { if
		 * (quote.getType().equals(type)) { count++; } }
		 */
		for (int i = 0; i < numberOfQuotes; i++) {
			if (type == null || (type != null && allQuotes[i].getType().equals(type))) {
				count++;
			}

		}
		/* Creating new array */
		Quote[] newArray = new Quote[count];

		int k = 0;
		for (int i = 0; i < numberOfQuotes; i++) {
			if (type == null || (type != null && allQuotes[i].getType().equals(type))) {
				/* We are not doing deep copy */
				newArray[k++] = allQuotes[i];
			}
		}

		return newArray;
	}

	public QuoteManager getManagerWithQuotes(String type) {
		/*
		 * Notice how we can create a QuoteManager, initialize it and return it.
		 */

		Quote[] selectedQuotes = getQuotes(type);
		QuoteManager newManager = new QuoteManager(selectedQuotes.length);
		newManager.allQuotes = selectedQuotes;
		newManager.numberOfQuotes = selectedQuotes.length;

		/*
		 * What operation will not be successful with the new manager? How would you fix
		 * it?
		 */

		return newManager;
	}
}
