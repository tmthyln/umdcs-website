package examples;

public class Quote {
	private String quote, type;

	public Quote(String quote, String type) {
		this.quote = quote;
		this.type = type;
	}

	/* 
	 * If we are not planning to add setMethods, do
	 * we need a copy constructor?
	 */
	public String getType() {
		return type;
	}
	
	public String toString() {
		return "\"" + quote + "\" (" + type + ")";
	}
}
