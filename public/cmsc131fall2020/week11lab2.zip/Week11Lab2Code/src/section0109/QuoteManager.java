package section0109;
import java.util.Random;

public class QuoteManager {
	private Quote[] allQuotes;
	private int numberOfQuotes;

	public QuoteManager(int maxQuotes) {
		allQuotes = new Quote[maxQuotes];
		numberOfQuotes = 0;
	}

	public boolean addQuote(String quote, String type) {
		if (numberOfQuotes == allQuotes.length) {
			return false;
		}
		
		allQuotes[numberOfQuotes++] = new Quote(quote, type);
		return true;
	}

	public void printQuotes(String type) {
		for (int i = 0; i < numberOfQuotes; i++) {
			Quote quote = allQuotes[i];
			if (type == null || quote.getType().equals(type)) {
				System.out.println(quote);
			}
		}
	}

	/* Getting random quote */
	public Quote getRandomQuote(Random random) {
		return allQuotes[random.nextInt(numberOfQuotes)];
	}
	
	/* Finding how many quotes of a particular type */
	public Quote[] getQuotes(String type) {
		Quote[] quotesType;
		int countType = 0;
		
		for (int i = 0; i < numberOfQuotes; i++) {
			if (type == null || allQuotes[i].getType().equals(type)) {
				countType++;
			}
		}
		
		quotesType = new Quote[countType];
		
		int indexQuotesType = 0;
		for (int i = 0; i < numberOfQuotes; i++) {
			if (type == null || allQuotes[i].getType().equals(type)) {
				quotesType[indexQuotesType++] = allQuotes[i];
			}
		}
		
		return quotesType;
	}

	public QuoteManager getManagerWithQuotes(String type) {
		Quote[] quotes = getQuotes(type);
		
		QuoteManager manager = new QuoteManager(quotes.length);
		manager.allQuotes = quotes;
		
		return manager;
	}
}
