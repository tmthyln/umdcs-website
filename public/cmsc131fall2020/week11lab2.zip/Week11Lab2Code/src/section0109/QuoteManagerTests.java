package section0109;

import static org.junit.Assert.assertEquals;

import java.util.Random;

import org.junit.Test;

public class QuoteManagerTests {

	@Test
	public void test01EmptyQuoteManager() {
		int maxQuotes = 10;
		QuoteManager manager = new QuoteManager(maxQuotes);
		manager.printQuotes(null);
	}

	@Test
	public void test02BasicAddPrint() {
		int maxQuotes = 10;
		QuoteManager manager = new QuoteManager(maxQuotes);
		manager.addQuote("If opporunity doesn't knock, make a door.", "life");
		manager.printQuotes(null);
	}
	
	@Test
	public void test03BasicAddPrint2() {
		int maxQuotes = 10;
		QuoteManager manager = new QuoteManager(maxQuotes);
		manager.addQuote("If opporunity doesn't knock, make a door.", "life");
		manager.printQuotes(new String("life"));
	}
	
	@Test
	public void test04RandomQuote() {
		int maxQuotes = 10;
		QuoteManager manager = new QuoteManager(maxQuotes);
		manager.addQuote("If opporunity doesn't knock, make a door.", "life");
		manager.addQuote("One small step for man, one giant leap for mankind.", "space");
		manager.addQuote("Strive not to be a success, but rather to be of value.", "work");
		manager.addQuote("Whenever you find yourself on the side of the majority it is time to stop and reflect.", "life");
		
		String expected = "\"Strive not to be a success, but rather to be of value.\" (work)";
		Quote quote = manager.getRandomQuote(new Random(17));
		assertEquals(expected, quote.toString());
	}
	
	@Test
	public void test05GetQuotes() {
		int maxQuotes = 10;
		QuoteManager manager = new QuoteManager(maxQuotes);
		
		manager.addQuote("Change the world by being yourself.", "life");
		manager.addQuote("Besides chocolate you are my favorite.", "romance");
		manager.addQuote("Simplicity is the ultimate sophistication.", "work");
		manager.addQuote("Yesterday you said tomorrow. Just do it.","life");
		manager.addQuote("Don't be busy, be productive.", "work");
		manager.addQuote("I need you like a heart needs a beat.", "romance");
		
		manager.printQuotes(null);
	}
}
