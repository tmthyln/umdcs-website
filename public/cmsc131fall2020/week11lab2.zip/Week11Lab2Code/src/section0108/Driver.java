package section0108;
import java.util.Arrays;
import java.util.Random;

public class Driver {

	public static void main(String[] args) {
		Quote quote = new Quote("To Be or Not to Be", "life");
		System.out.println(quote);
		
		int maxQuotes = 10;
		QuoteManager manager = new QuoteManager(maxQuotes);
		manager.printQuotes(null);
		
		manager.addQuote("Change the world by being yourself.", "life");
		manager.addQuote("Besides chocolate you are my favorite.", "romance");
		manager.addQuote("Simplicity is the ultimate sophistication.", "work");
		manager.addQuote("Yesterday you said tomorrow. Just do it.","life");
		manager.addQuote("Don't be busy, be productive.", "work");
		manager.addQuote("I need you like a heart needs a beat.", "romance");
		
		manager.printQuotes(null);
		manager.printQuotes("work");
		
		Random random = new Random();
		System.out.println("\nRandom Quote: " + manager.getRandomQuote(random));
		
		Quote[] lifeQuotes = manager.getQuotes("life");
		
		/* Arrays.toString() allow us to avoid using a loop.  Arrays class
		 * provides useful support methods 
		 */
		System.out.println("Life quotes: " + Arrays.toString(lifeQuotes));
		
		QuoteManager newManager = manager.getManagerWithQuotes(null);
		newManager.printQuotes("romance");
	}
}
