package section0108;
import java.util.Random;

public class QuoteManager {
	private Quote[] allQuotes;
	private int numberOfQuotes;

	public QuoteManager(int maxQuotes) {
		allQuotes = new Quote[maxQuotes];
		numberOfQuotes = 0;
	}

	public boolean addQuote(String quote, String type) {
		if (numberOfQuotes == allQuotes.length) {
			return false;
		}
		
		allQuotes[numberOfQuotes++] = new Quote(quote, type);
		return true;
	}

	public void printQuotes(String type) {
		for (int i = 0; i < numberOfQuotes; i++) {
			Quote quote = allQuotes[i];
			if (quote.getType().equals(type)) {
				System.out.println(quote);
			}
		}
	}

	/* Getting random quote */
	public Quote getRandomQuote(Random random) {
		int index = random.nextInt(numberOfQuotes);
		return allQuotes[index];
	}
	

	/* Finding how many quotes of a particular type */
	public Quote[] getQuotes(String type) {
		Quote[] typeQuotes;
		int typeCount = 0;
		
		for (int i = 0; i < numberOfQuotes; i++) {
			if (allQuotes[i].getType().equals(type)) {
				typeCount++;
			}
		}
		
		typeQuotes = new Quote[typeCount];
		
		int newIndex = 0;
		for (int i = 0; i < numberOfQuotes; i++) {
			if (allQuotes[i].getType().equals(type)) {
				typeQuotes[newIndex++] = allQuotes[i];
			}
		}
		
		return typeQuotes;
	}

	public QuoteManager getManagerWithQuotes(String type) {
		Quote[] quotes = getQuotes(type);
		
		QuoteManager manager = new QuoteManager(quotes.length);
		manager.allQuotes = quotes;
		
		return manager;
	}
}
