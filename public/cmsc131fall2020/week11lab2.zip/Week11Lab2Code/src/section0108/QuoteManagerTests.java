package section0108;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Random;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class QuoteManagerTests {

	@Test
	public void test01BasicAddPrint() {
		QuoteManager manager = new QuoteManager(5);
		manager.addQuote("One small step for man, one giant leap for mankind.", "space");
		manager.printQuotes(new String("space"));
		String expected = "\"One small step for man, one giant leap for mankind.\"(space)";
	}
	
	@Test
	public void test02MultipleAdds() {
		QuoteManager manager = new QuoteManager(5);
		manager.addQuote("One small step for man, one giant leap for mankind.", "space");
		manager.addQuote("One small step for man, one giant leap for mankind.", "space");
		manager.addQuote("One small step for man, one giant leap for mankind.", "space");
		manager.addQuote("One small step for man, one giant leap for mankind.", "space");
		manager.addQuote("One small step for man, one giant leap for mankind.", "space");
		manager.printQuotes(new String("space"));
		String expected = "\"One small step for man, one giant leap for mankind.\"(space)";
	}
	
	@Test
	public void test03Overflow() {
		boolean result;
		
		QuoteManager manager = new QuoteManager(5);
		manager.addQuote("One small step for man, one giant leap for mankind.", "space");
		manager.addQuote("One small step for man, one giant leap for mankind.", "space");
		manager.addQuote("One small step for man, one giant leap for mankind.", "space");
		manager.addQuote("One small step for man, one giant leap for mankind.", "space");
		
		result = manager.addQuote("One small step for man, one giant leap for mankind.", "space");
		assertTrue(result);
		
		result = manager.addQuote("One small step for man, one giant leap for mankind.", "space");
		assertFalse(result);
	}
	
	@Test
	public void test04RandomElement() {
		QuoteManager manager = new QuoteManager(5);
		manager.addQuote("One small step for man, one giant leap for mankind.", "space");
		manager.addQuote("Be yourself; everyone else is already taken.", "life");
		manager.addQuote("If opportunity doesn't knock, build a door.", "life");
		manager.addQuote("Can I call you son? You can call me daddy.", "nelson");
		
		Quote quote = manager.getRandomQuote(new Random(17));
		
		assertEquals("\"If opportunity doesn't knock, build a door.\" (life)", quote.toString());
	}

}
