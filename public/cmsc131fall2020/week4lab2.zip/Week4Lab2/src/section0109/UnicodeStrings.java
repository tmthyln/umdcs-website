package section0109;

public class UnicodeStrings {
    
    public static void main(String[] args) {
	String top13 = "😂😭🥺🤣❤️✨😍🙏😊🥰👍💕🤔";
	System.out.println("Number of Code Units: " + top13.length());
	
	for (int i = 0; i < top13.length(); i++) {
	    System.out.print(top13.charAt(i));
	    if (i < top13.length() - 1)
		System.out.print(" ");
	}
	System.out.println();
	
	for (String c: top13.split(""))
	    System.out.print(c);
	System.out.println();
    }

}
