package section0109;

public class VerifyPassword {

    public static void main(String[] args) {
	if (verifyPassword("password", 10) == 1)  {
	    System.out.println("Correctly determined `password` is too short.");
	}
	if (verifyPassword("password1", 8) == 3) {
	    System.out.println("Correctly determined `password1` is not valid.");
	}
	if (verifyPassword("Password", 8) == 3) {
	    System.out.println("Correctly determined `Password` is not valid.");
	}
	if (verifyPassword("Password1", 8) == 2) {
	    System.out.println("Correctly determined `Password1` is valid.");
	}

    }
    
    public static int verifyPassword(String password, int minLength) {
	// alternative implementation; pretty much what was shared during lab
	
	if (password.length() < minLength) {
	    return 1;
	}
	
	boolean hasDigit = false, hasUpperCase = false;
	for (int i = 0; i < password.length(); i++) {
	    if (Character.isDigit(password.charAt(i))) {
		hasDigit = true;
	    }
	    
	    if (Character.isUpperCase(password.charAt(i))) {
		hasUpperCase = true;
	    }
	}
	
	if (hasDigit == true && hasUpperCase == true) {
	    return 2;
	} else {
	    return 3;
	}
    }

}
