package section0109;

public class PrintAscii {

	public static void main(String[] args) {
		for (int i = 33; i < 126; i++) {
			System.out.print((char) i + " ");
		}
	}

}
