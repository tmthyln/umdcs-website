package section0108;

public class VerifyPassword {

    /*
    A valid password is at least minLength characters, at least one digit 
    (use Character.isDigit), at least 1 uppercase character (use Character.isUpperCase)
    
    The method returns 1 if too short, 2 if valid, 3 if otherwise invalid.
    
    Hint: for having at least 1 digit and 1 uppercase character start off with 
    a for-loop that goes character by character (the charAt method for strings might be useful here)
    */
    
    public static void main(String[] args) {
	
	if (verifyPassword("password", 10) == 1) {
	    System.out.println("This should be printed.");
	}
	
	if (verifyPassword("password1", 6) == 3) {
	    System.out.println("This should also be printed");
	}
	
	if (verifyPassword("Password", 6) == 3) {
	    System.out.println("This should also also be printed");
	}
	
	if (verifyPassword("Password1", 6) == 2) {
	    System.out.println("This password is finally valid.");
	}
	
    }
    
    public static int verifyPassword(String password, int minLength) {
	if (password.length() < minLength) {
	    return 1;
	}
	
	boolean hasDigit = false, hasUpperCase = false;
	for (int i = 0; i < password.length(); i++) {
	    if (Character.isDigit(password.charAt(i))) {
		hasDigit = true;
	    }
	    
	    if (Character.isUpperCase(password.charAt(i))) {
		hasUpperCase = true;
	    }
	}
	
	if (hasDigit == true && hasUpperCase == true) {
	    return 2;
	} else {
	    return 3;
	}
    }
    

}
