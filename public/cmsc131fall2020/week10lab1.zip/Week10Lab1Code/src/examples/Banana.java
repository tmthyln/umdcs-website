package examples;

public class Banana {
	private int length;
	private boolean peeled;
	private StringBuffer owner;
	
	public Banana(int length, boolean peeled, StringBuffer owner) {
		this.length = length;
		this.peeled = peeled;
		this.owner = new StringBuffer(owner);
	}
	
	public Banana(int length, StringBuffer owner) {
		this(length, false, owner);
	}
	
	public Banana(Banana banana) {
		this(banana.length, banana.peeled, banana.owner);
	}
	
	public void peel() {
		peeled = true;
	}
	
	public String getOwner() {
		return owner.toString();
	}
	
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		} else if (obj == null) {
			return false;
		} else if (getClass() != obj.getClass()) {
			return false;
		} else {
			Banana that = (Banana) obj;
			
			return this.length == that.length && this.peeled == that.peeled;
		}
	}
	
}
