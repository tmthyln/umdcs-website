package examples;

import java.util.ArrayList;

public class Basket {
	private ArrayList<Apple> basket;
	
	public Basket() {
		basket = new ArrayList<Apple>();
	}
	
	public void addApple(Apple apple) {
		basket.add(apple);
	}
	
	public Apple eatApple() {
		if (basket.isEmpty()) {
			return null;
		}
		
		return basket.remove(0);
	}
	
	public boolean eatApple(Apple apple) {
		return basket.remove(apple);
	}
	
	public ArrayList<Apple> getMyApples(String owner) {
		ArrayList<Apple> theirApples = new ArrayList<Apple>();
		
		for (Apple apple: basket) {
			if (apple.getOwner().equals(owner)) {
				theirApples.add(apple);
			}
		}
		
		return theirApples;
	}
}
