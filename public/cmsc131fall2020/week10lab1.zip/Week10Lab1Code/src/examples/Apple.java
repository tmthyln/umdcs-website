package examples;

public class Apple {
	 private int weight;
	 private boolean hasSeeds;
	 private StringBuffer owner;
	 
	 private static int numApples;
	 
	 public Apple(int weight, boolean hasSeeds, StringBuffer owner) {
		 this.weight = weight;
		 this.hasSeeds = hasSeeds;
		 this.owner = new StringBuffer(owner);
		 
		 numApples++;
	 }
	 
	 public Apple(int weight, StringBuffer owner) {
		 this(weight, true, owner);
	 }
	 
	 public Apple(Apple other) {
		 this(other.weight, other.hasSeeds, other.owner);
	 }
	 
	 public String getOwner() {
		 return owner.toString();
	 }
	 
	 public boolean equals(Object o) {
		 if (this == o) {
			 return true;
		 } else if (o == null) {
			 return false;
		 } else if (getClass() != o.getClass()) {
			 return false;
		 } else {
			 Apple that = (Apple) o;
			 
			 return this.weight == that.weight && this.hasSeeds == that.hasSeeds;
		 }
	 }
	 
}
