package examples;

import java.util.ArrayList;

public class Bunch {
	private ArrayList<Banana> bananas;
	
	public Bunch() {
		bananas = new ArrayList<Banana>();
	}
	
	public void addBanana(Banana banana) {
		bananas.add(banana);
	}
	
	public Banana eatBanana() {
		if (bananas.isEmpty()) {
			return null;
		}
		
		return bananas.remove(0);
	}
	
	public void peelFirstBanana() {
		if (!bananas.isEmpty()) {
			bananas.get(0).peel();
		}
	}
	
	public ArrayList<Banana> getMyBananas(String owner) {
		ArrayList<Banana> theirBananas = new ArrayList<Banana>();
		
		for (Banana banana: bananas) {
			if (banana.getOwner().equals(owner)) {
				theirBananas.add(banana);
			}
		}
		
		return theirBananas;
	}
}
