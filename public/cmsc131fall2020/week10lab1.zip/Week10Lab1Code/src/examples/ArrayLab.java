package examples;

public class ArrayLab {

	public static int total = 10;
	
	public static void task(String[] guests) {
		guests[1] = "Mary";
		/* Look at guests array in debugger */
		/* Notice how names in main and guests in task 
		 * have the same address (id=...)
		 */
	}
	
	public static void main(String[] args) {
		int size = 3; /* Try with size 0 after using 3 */
		
		int[] scores = new int[size];
		/* Look at scores array in debugger */
		
		scores[1] = 300;
		/* Look at scores array in debugger */

		String[] names = new String[size]; 
		/* Look at names array in debugger */
		
		String john = new String("John");
		names[0] = john;
		/* Look at names array and john in debugger */
		
		task(names);
	}
}
