package programs;

import csPictureLib.Picture;
import csPictureLib.PictureColor;

/**
 * While a simple average of the RGB values for each pixel is a good way to get
 * a grayscale image, sometimes, we want to use a weighted average. For example,
 * the human eye actually perceives green more strongly and blue less strongly,
 * so we can adjust the "weights" accordingly.
 */
public class Grayscale implements Picture {
	Picture sourceImage;

	public Grayscale(Picture sourceImage) {
		this.sourceImage = sourceImage;
	}

	@Override
	public PictureColor getColor(int x, int y) {
		PictureColor color = sourceImage.getColor(x, y);
		double red = color.getRed(), green = color.getGreen(), blue = color.getBlue();

		// these are pretty good default weights, but you can change them and see what
		// their effect is
		double gray = 0.2 * red + 0.7 * green + 0.1 * blue;

		return new PictureColor(gray, gray, gray);
	}

	@Override
	public int getWidth() {
		return sourceImage.getWidth();
	}

	@Override
	public int getHeight() {
		return sourceImage.getHeight();
	}

}
