package programs;

import csPictureLib.Picture;
import csPictureLib.PictureColor;

/**
 * Color-keying is basically what green screens do. We have a foreground image
 * and a background image. If a pixel in the foreground image is close to our
 * key color (the color we want to remove, often green), then we substitute it
 * with a pixel from the background image.
 * 
 * Usually, you'll have to tune the target color and the threshold for the
 * specific images/videos you're using.
 */
public class ColorKey implements Picture {
	private Picture fgImage, bgImage;
	private PictureColor target;
	private double threshold;

	public ColorKey(Picture fgImage, Picture bgImage, PictureColor target, double threshold) {
		this.fgImage = fgImage;
		this.bgImage = bgImage;
		this.target = target;
		this.threshold = threshold;
	}
	
	public ColorKey(Picture fgImage, Picture bgImage, PictureColor target) {
		this(fgImage, bgImage, target, 0.3);
	}

	@Override
	public PictureColor getColor(int x, int y) {
		if (colorDistance(target, fgImage.getColor(x, y)) < threshold) {
			return bgImage.getColor(x, y);
		} else {
			return fgImage.getColor(x, y);
		}
	}

	/**
	 * One way of calculating the distance/difference between 2 colors.
	 */
	private double colorDistance(PictureColor target, PictureColor actual) {
		double redDist = Math.pow((target.getRed() - actual.getRed()), 2);
		double greenDist = Math.pow((target.getGreen() - actual.getGreen()), 2);
		double blueDist = Math.pow((target.getBlue() - actual.getBlue()), 2);

		return Math.sqrt(redDist + greenDist + blueDist);
	}

	@Override
	public int getWidth() {
		return fgImage.getWidth();
	}

	@Override
	public int getHeight() {
		return fgImage.getHeight();
	}

}
