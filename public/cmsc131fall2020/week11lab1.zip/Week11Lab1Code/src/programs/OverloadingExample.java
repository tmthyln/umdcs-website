package programs;

import java.util.ArrayList;

public class OverloadingExample {

	public static int process(ArrayList<Integer> scores) {
		int sum = 0;

		for (int i = 0; i < scores.size(); i++) {
			sum += scores.get(i);
		}

		return sum;
	}

	/* Overloads process method */
	public static int process(int x, int y) {
		return (x + y) / 2;
	}
	
	/* Overloads process method */
	public static boolean process(boolean x, boolean y) {
		return x == y;
	}

	/*
	 * The return type of a method does not influence overloading. If you were to
	 * define the following method, you will be duplicating a method (see the
	 * compilation error).
	 */
	/*
	 * public static boolean process(ArrayList<Integer> scores) { return
	 * scores.size() > 0; }
	 */

	public static void main(String[] args) {
		/*
		 * Compiler will pick the appropriate method based on the number and type of
		 * arguments (the same process that takes place with constructors).
		 */

		/* We need wrapper Integer; cannot use int */
		ArrayList<Integer> values = new ArrayList<Integer>();
		values.add(10);
		values.add(20);

		System.out.println("Sum: " + process(values));
		System.out.println("Average: " + process(100, 80));
		System.out.println("Boolean Values: " + process(true, false));

		/* We don't need to specify the type (this is not related to overloading) */
		ArrayList<Integer> additionalValues = new ArrayList<>();
		additionalValues.add(100);
		System.out.println(additionalValues);
	}
}
