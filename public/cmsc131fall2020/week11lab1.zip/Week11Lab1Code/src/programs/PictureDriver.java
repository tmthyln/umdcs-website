package programs;

import csPictureLib.*;

public class PictureDriver {
	/*
	 * Check the interfaces and classes in the csPictureLib as you go over this
	 * code.
	 */
	public static void main(String[] args) {
		String testudoImage = "testudo.jpg"; /* Can try with umcp1.jpg */

		Picture picture; /* Look at the Picture interface and the methods it declares */
		picture = new Image(testudoImage); /* Image class implements Picture */

		/* Because an Image is a Picture, we can execute the following methods */
		System.out.println("Width: " + picture.getWidth());
		System.out.println("Height: " + picture.getHeight());

		/* PictureUtil.show displays a picture */
		PictureUtil.show(picture);

		/* We can retrieve the color of a particular pixel */
		int x = 10, y = 20;
		System.out.println("Color (Red, Green, Blue): " + picture.getColor(x, y));

		/* We can take any class that is a Picture and turned it into BlackAndWhite */
		Picture blackAndWhite = new BlackAndWhite(picture);
		PictureUtil.show(blackAndWhite);
		
		/* We can make it a custom grayscale image */
		Picture grayscale = new Grayscale(picture);
		PictureUtil.show(grayscale);
		
		/* We can blur the image (with varying amounts of blur) */
		Picture blurred = new Blur(picture, 2);
		PictureUtil.show(blurred);

		/* We can combine two pictures */
		Picture combinedLeftRight = new CombineLeftRight(picture, blackAndWhite);
		PictureUtil.show(combinedLeftRight);
		
		/* We can do color keying (similar to green screen work) */
		Picture colorKeyed = new ColorKey(picture, new Image("umcp1.jpg"), new PictureColor(0.5, 0, 0.3));
		PictureUtil.show(colorKeyed);

		/* We can take the previous picture and posterize it */
		Picture posterized = new Posterize(combinedLeftRight);
		PictureUtil.show(posterized);
		
		/* We can do anything we want to the pixels */
		Picture myPictures = new MyPictureClass(combinedLeftRight);
		PictureUtil.show(myPictures);
		/*
		 * Because posterized is a Picture, we can execute getWidth, getHeight, getColor
		 */
		System.out.println("Posterized width: " + posterized.getWidth());
		System.out.println("Posterized height: " + posterized.getHeight());
	}
}
