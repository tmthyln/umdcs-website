package programs;

import csPictureLib.*;

/**
 * Defines a class where the red component of the original picture is removed.
 * 
 * @author CS
 *
 */
public class MyPictureClass implements Picture {
	private Picture source;

	public MyPictureClass(Picture source) {
		this.source = source;
	}

	/*
	 * If we don't define these methods the class will not compile.
	 */
	public PictureColor getColor(int x, int y) {
		PictureColor origColor = source.getColor(x, y);
		double redValue = 0, greenValue = origColor.getGreen();
		double blueValue = origColor.getBlue();

		/* Creating new pixel, eliminating red component */
		return new PictureColor(redValue, greenValue, blueValue);
	}

	public int getWidth() {
		return source.getWidth();
	}

	public int getHeight() {
		return source.getHeight();
	}
}
