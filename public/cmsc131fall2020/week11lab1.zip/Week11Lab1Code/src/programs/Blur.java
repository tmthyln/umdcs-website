package programs;

import csPictureLib.Picture;
import csPictureLib.PictureColor;

/**
 * Here, we're blurring an image by averaging the RGB values for pixels near
 * each pixel. To get a "blurrier" blur, you can make the radius bigger (average
 * over a bigger area).
 * 
 * This particular blur is an average blur (because we are just averaging the
 * RGB values directly). Better blurs can be achieved with weighted averages
 * with different weights (e.g. Gaussian blur).
 */
public class Blur implements Picture {
	Picture sourceImage;
	int radius;

	public Blur(Picture sourceImage, int blurRadius) {
		this.sourceImage = sourceImage;
		this.radius = blurRadius;
	}

	public Blur(Picture sourceImage) {
		this(sourceImage, 1);
	}

	@Override
	public PictureColor getColor(int x, int y) {
		double red = 0, green = 0, blue = 0;
		
		for (int i = x - radius; i <= x + radius; i++) {
			for (int j = y - radius; j <= y + radius; j++) {
				PictureColor sourceColor = sourceImage.getColor(i, j);
				
				// first get the sum of all nearby pixels
				red += sourceColor.getRed();
				green += sourceColor.getGreen();
				blue += sourceColor.getBlue();
			}
		}

		// use the average RGB values
		int numPixels = (2 * radius + 1) * (2 * radius + 1);
		return new PictureColor(red / numPixels, green / numPixels, blue / numPixels);
	}

	@Override
	public int getWidth() {
		return sourceImage.getWidth();
	}

	@Override
	public int getHeight() {
		return sourceImage.getHeight();
	}

}
