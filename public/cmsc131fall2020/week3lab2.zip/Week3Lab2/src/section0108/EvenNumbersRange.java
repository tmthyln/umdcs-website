package section0108;

import java.util.Scanner;

public class EvenNumbersRange {

    public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);

	while (true) {
	    System.out.print("Enter a range: ");
	    int lower = scanner.nextInt();
	    int upper = scanner.nextInt();
	    
	    for (int num = lower; num <= upper; num++) {
		if (num % 2 == 0) {
		    System.out.print(num + " ");
		}
	    }
	    System.out.println();
	}
    }

}
