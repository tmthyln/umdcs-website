package section0108;

import java.util.Scanner;

public class Rectangle {

    public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);

	System.out.print("Enter a character: ");
	String charString = scanner.nextLine();
	System.out.print("Enter width and height: ");
	int width = scanner.nextInt();
	int height = scanner.nextInt();
	
	for (int row = 0; row < height; row++) {
	    for (int col = 0; col < width; col++) {
		System.out.print(charString);
	    }
	    System.out.println();
	}
	
    }

}
