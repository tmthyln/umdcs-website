package section0109;

import java.util.Scanner;

public class LeftTriangle {

    public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);

	System.out.print("Enter height: ");
	int height = scanner.nextInt();
	
	for (int row = 0; row < height; row++) {
	    for (int col = 0; col < row + 1; col++) {
		System.out.print("*");
	    }
	    System.out.println();
	}

    }

}
