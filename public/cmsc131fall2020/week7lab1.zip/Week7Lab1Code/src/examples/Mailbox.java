package examples;

public class Mailbox {
    private int maxCapacity, numberOfMessages;
    private StringBuffer messages;

    /**
     * Initializes a Mailbox object with the specified maxCapacity if the
     * maxCapacity value is valid according to isValidCapacity. Assigns to messages
     * a StringBuffer object and initializes the number of messages to 0.
     * 
     * @param maxCapacity Maximum Capacity.
     */
    public Mailbox(int maxCapacity) {
	if (isValidCapacity(maxCapacity)) {
	    this.maxCapacity = maxCapacity;
	} else {
	    this.maxCapacity = 1;
	}
	messages = new StringBuffer();
	numberOfMessages = 0; /* Do we really have to set it to 0? */
    }

    public String toString() {
	return "Max Capacity: " + maxCapacity + ", " + messages;
    }

    /**
     * Adds the specified message to the mailbox if their capacity. A "|" will be
     * added after the message. The number of messages will be increased
     * accordingly.
     * 
     * @param message Message to add to mailbox.
     * @return Reference to current object.
     */
    public Mailbox addMessage(String message) {
	if (numberOfMessages < maxCapacity) {
	    messages.append(message + "|");
	    numberOfMessages++;
	}

	/* Next statement will allow us to add messages in a chain */
	/* For example, m.addMessage("hello").addMessage("eating"); */
	return this;
    }

    /**
     * Initializes the Mailbox object using the maxCapacity parameter and adds the
     * specified message.
     * 
     * @param message     Provided message.
     * @param maxCapacity Maximum capacity.
     */
    public Mailbox(String message, int maxCapacity) {
	this(maxCapacity); /* Calling previous constructor */
	addMessage(message);
    }

    /**
     * Increases the maximum capacity if the parameter value exceeds the current
     * maxCapacity.
     * 
     * @param maxCapacity New maximum capacity value.
     * @return True if capacity was increased; false otherwise.
     */
    public boolean increaseCapacity(int maxCapacity) {
	if (isValidCapacity(maxCapacity) && maxCapacity > this.maxCapacity) {
	    this.maxCapacity = maxCapacity;
	    return true;
	}

	return false;
    }

    /* Private method; avoids code duplication */
    private boolean isValidCapacity(int maxCapacity) {
	return maxCapacity >= 1 && maxCapacity <= 25;
    }
}
