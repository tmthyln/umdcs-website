package examples;

import static org.junit.Assert.*;

import org.junit.Test;

public class StudentTests {

	@Test
	public void test1() {
		Mailbox mailbox = new Mailbox(4);
		mailbox.addMessage("Welcome to lab").addMessage("Today is Monday");
		
		System.out.println(mailbox);
	}

	@Test
	public void test2() {
		Mailbox mailbox = new Mailbox("Fall", 4);
		String answer = mailbox.toString();
		
		mailbox.increaseCapacity(5);
		answer += "\n" + mailbox;
		mailbox.increaseCapacity(100);
		answer += "\n" + mailbox;
		
		System.out.println(answer);
	}
}
