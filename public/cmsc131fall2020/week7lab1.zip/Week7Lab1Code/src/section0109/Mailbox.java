package section0109;

public class Mailbox {
    private int maxCapacity, numberOfMessages;
    private StringBuffer messages;

    /**
     * Initializes a Mailbox object with the specified maxCapacity if the
     * maxCapacity value is valid according to isValidCapacity. If the maxCapacity
     * is not valid, initializes the maxCapacity to 1. Assigns to messages
     * a StringBuffer object and initializes the number of messages to 0.
     * 
     * @param maxCapacity Maximum Capacity.
     */
    public Mailbox(int maxCapacity) {
	if (isValidCapacity(maxCapacity)) {
	    this.maxCapacity = maxCapacity;
	} else {
	    this.maxCapacity = 1;
	}
	
	messages = new StringBuffer();
	numberOfMessages = 0;
    }
    
    /**
     * Initializes the Mailbox object using the maxCapacity parameter and adds the
     * specified message as the first message.
     * 
     * @param message     Provided message.
     * @param maxCapacity Maximum capacity.
     */
    public Mailbox(String message, int maxCapacity) {
	this(maxCapacity);
	addMessage(message);
    }

    /**
     * Creates a string representation of this mailbox that has the maximum 
     * capacity and the messages in the mailbox.
     */
    public String toString() {
	return "Max Capacity: " + maxCapacity + 
		", Messages (" + numberOfMessages + "): " + messages;
    }

    /**
     * Adds the specified message to the mailbox if there's capacity. A "|" will 
     * be added after the message. The number of messages will be increased
     * accordingly.
     * 
     * @param message Message to add to mailbox.
     * @return Reference to current object.
     */
    public Mailbox addMessage(String message) {
	if (numberOfMessages < maxCapacity) {
	    messages.append(message + "|");
	    numberOfMessages++;
	}
	
	return this;
    }

    /**
     * Increases the maximum capacity if the parameter value exceeds the current
     * maxCapacity and the new maximum capacity is valid.
     * 
     * @param maxCapacity New maximum capacity value.
     * @return True if capacity was increased; false otherwise.
     */
    public boolean increaseCapacity(int maxCapacity) {
	throw new UnsupportedOperationException("not implemented");
    }

    /**
     * Checks whether a max capacity is valid. A valid max capacity is in the 
     * (inclusive) range 1-25.
     */
    private boolean isValidCapacity(int maxCapacity) {
	return maxCapacity >= 1 && maxCapacity <= 25;
    }
    
}
