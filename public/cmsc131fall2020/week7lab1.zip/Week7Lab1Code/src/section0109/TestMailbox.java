package section0109;

import org.junit.Test;

public class TestMailbox {

    @Test
    public void testOneParameterConstructor() {
	Mailbox mailbox = new Mailbox(2);
	
	System.out.println(mailbox);
    }
    
    @Test
    public void testCapacityValidConstructor() {
	Mailbox mailbox = new Mailbox(100);
	
	System.out.println(mailbox);
    }
    
    @Test
    public void testTwoParameterConstructor() {
	Mailbox mailbox2 = new Mailbox("Greetings!", 3);
	
	System.out.println(mailbox2);
    }
    
    @Test
    public void testMethodChaining() {
	Mailbox mailbox = new Mailbox(5);
	
	mailbox
		.addMessage("Greetings!")
		.addMessage("Bienvenue!")
		.addMessage("Bienvenidos!");
	
	System.out.println(mailbox);
    }

}
