package section0108;

public class HourglassMath {

    public static void main(String[] args) {
	int size = 5;
	
	for (int row = 0; row < size; row++) {
	    for (int col = 0; col < row; col++) {
		System.out.print(" ");
	    }
	    for (int col = 0; col < 2 * (size - row); col++) {
		System.out.print("#");
	    }
	    System.out.println();
	}
	
	for (int row = 0; row < size; row++) {
	    for (int col = 0; col < size - row - 1; col++) {
		System.out.print(" ");
	    }
	    for (int col = 0; col < 2 * (row + 1); col++) {
		System.out.print("#");
	    }
	    System.out.println();
	}

    }

}
