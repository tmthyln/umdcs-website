package section0108;

public class HourglassVariables {

    public static void main(String[] args) {
	int size = 10;
	
	int spaces = 0, symbols = 2 * size;
	for (int row = 0; row < 2*size; row++) {
	    
	    for (int col = 0; col < spaces; col++) {
		System.out.print(" ");
	    }
	    
	    for (int col = 0; col < symbols; col++) {
		System.out.print("#");
	    }
	    
	    System.out.println();
	    
	    if (row < size / 3) {
		spaces += 2;
		symbols -= 4;
	    } else if (row < 3 * size / 4) {
		spaces--;
		symbols += 2;
	    } else if (row < 3 * size / 2) {
		
	    } else {
		symbols -= 4;
		spaces += 2;
	    }
	    /*
	    if (row < size - 1) {
		spaces++;
	    	symbols -= 2;
	    } else if (row < size) {
		
	    } else { // means row >= size
		spaces--;
		symbols += 2;
	    }
	    */
	}

    }

}
